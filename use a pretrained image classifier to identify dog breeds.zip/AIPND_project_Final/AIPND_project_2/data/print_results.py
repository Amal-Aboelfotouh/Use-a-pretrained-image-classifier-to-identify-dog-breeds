def print_results(results_dic, results_stats_dic, model, 
                  print_incorrect_dogs=False, print_incorrect_breed=False):
    """
    Prints summary results on the classification and then prints incorrectly 
    classified dogs and incorrectly classified dog breeds if the user indicates 
    they want those printouts.
    """
    print("\n\n*** Results Summary for CNN Model Architecture", model.upper(), "***")
    print("{:20}: {:3d}".format('N Images', results_stats_dic['n_images']))
    print("{:20}: {:3d}".format('N Dog Images', results_stats_dic['n_dogs_img']))
    print("{:20}: {:3d}".format('N Not-Dog Images', results_stats_dic['n_notdogs_img']))

    print("\nStatistics:")
    for key in results_stats_dic:
        if key.startswith('p'):
            print("{:20}: {:5.1f}%".format(key, results_stats_dic[key]))


    if print_incorrect_dogs and (results_stats_dic['n_correct_dogs'] + results_stats_dic['n_correct_notdogs']
                                 != results_stats_dic['n_images']):
        print("\nINCORRECT Dog/NOT Dog Assignments:")


        for key in results_dic:
            pet_label = results_dic[key][0]
            classifier_label = results_dic[key][1]
            pet_is_dog = results_dic[key][3]
            classifier_is_dog = results_dic[key][4]

            if (pet_is_dog == 1 and classifier_is_dog == 0) or (pet_is_dog == 0 and classifier_is_dog == 1):
                print("Pet: {:>26}   Classifier: {:>30}".format(pet_label, classifier_label))

    if print_incorrect_breed and (results_stats_dic['n_correct_dogs'] != results_stats_dic['n_correct_breed']):
        print("\nINCORRECT Dog Breed Assignment:")
        for key in results_dic:
            pet_label = results_dic[key][0]
            classifier_label = results_dic[key][1]
            pet_is_dog = results_dic[key][3]
            correct_breed = results_dic[key][2]

            if (results_dic[key][3] == 1 and results_dic[key][4] == 1 and results_dic[key][2] == 0):
                print("Real: {:>26}   Classifier: {:>30}".format(pet_label, classifier_label))

